/**
 * inspector.js — JSON tree renderer + screenshot viewer for the Debug tab
 */

;(function() {
  'use strict';

  // ─── JSON Tree Renderer ──────────────────────────────────────

  function renderJson(data, container, depth) {
    depth = depth || 0;
    container.innerHTML = '';
    const el = buildNode(data, depth, true);
    container.appendChild(el);
  }

  function buildNode(value, depth, isRoot) {
    const type = Array.isArray(value) ? 'array'
               : value === null      ? 'null'
               : typeof value;

    if (type === 'object' || type === 'array') {
      return buildObjectNode(value, type, depth, isRoot);
    } else {
      return buildPrimitiveNode(value, type);
    }
  }

  function buildObjectNode(value, type, depth, isRoot) {
    const keys = Object.keys(value);
    const isEmpty = keys.length === 0;

    const wrapper = document.createElement('span');

    if (isEmpty) {
      wrapper.appendChild(text(type === 'array' ? '[]' : '{}'));
      return wrapper;
    }

    // Collapse if deep or large
    const collapsed = !isRoot && (depth > 2 || keys.length > 20);
    const isArr = type === 'array';
    const openBrace  = isArr ? '[' : '{';
    const closeBrace = isArr ? ']' : '}';

    const fold = document.createElement('span');
    fold.className = 'json-fold';

    const toggle = document.createElement('span');
    toggle.textContent = collapsed ? '▶ ' : '▼ ';
    toggle.style.fontSize = '9px';
    toggle.style.color = 'var(--color-text-muted)';

    const preview = document.createElement('span');
    preview.className = 'text-muted';
    preview.style.fontSize = '10px';

    const countLabel = `${keys.length} ${isArr ? 'items' : 'keys'}`;
    preview.textContent = collapsed ? ` ${openBrace}…${closeBrace} (${countLabel})` : '';

    fold.appendChild(toggle);
    fold.appendChild(text(openBrace));
    fold.appendChild(preview);

    const body = document.createElement('div');
    body.style.paddingLeft = '14px';
    body.style.display = collapsed ? 'none' : 'block';

    keys.forEach((key, i) => {
      const row = document.createElement('div');
      row.style.lineHeight = '1.6';

      const keySpan = document.createElement('span');
      keySpan.className = 'json-key';
      keySpan.textContent = isArr ? '' : `"${key}": `;

      row.appendChild(keySpan);
      row.appendChild(buildNode(value[key], depth + 1, false));

      if (i < keys.length - 1) row.appendChild(text(','));
      body.appendChild(row);
    });

    const closeRow = document.createElement('div');
    closeRow.appendChild(text(closeBrace));

    wrapper.appendChild(fold);
    wrapper.appendChild(body);
    wrapper.appendChild(closeRow);

    // Toggle on click
    fold.addEventListener('click', () => {
      const isNowCollapsed = body.style.display === 'none';
      body.style.display = isNowCollapsed ? 'block' : 'none';
      toggle.textContent = isNowCollapsed ? '▼ ' : '▶ ';
      preview.textContent = isNowCollapsed ? '' : ` ${openBrace}…${closeBrace} (${countLabel})`;
    });

    return wrapper;
  }

  function buildPrimitiveNode(value, type) {
    const span = document.createElement('span');
    if (type === 'string') {
      span.className = 'json-str';
      // Truncate very long strings
      const display = value.length > 200 ? value.slice(0, 200) + '…' : value;
      span.textContent = `"${display}"`;
      span.title = value.length > 200 ? value : '';
    } else if (type === 'number') {
      span.className = 'json-num';
      span.textContent = value;
    } else if (type === 'boolean') {
      span.className = 'json-bool';
      span.textContent = value;
    } else {
      span.className = 'json-null';
      span.textContent = 'null';
    }
    return span;
  }

  function text(str) {
    return document.createTextNode(str);
  }

  // ─── Screenshot viewer ───────────────────────────────────────

  function showScreenshot(base64, filePath, width, height) {
    const img = document.getElementById('screenshot-preview');
    const meta = document.getElementById('screenshot-meta');

    if (base64) {
      img.src = 'data:image/jpeg;base64,' + base64;
      img.style.display = 'block';
    } else {
      img.style.display = 'none';
    }

    if (meta) {
      meta.textContent = filePath
        ? `${width} × ${height}px · ${filePath}`
        : 'No screenshot captured.';
    }
  }

  // ─── Export ──────────────────────────────────────────────────

  window.inspector = { renderJson, showScreenshot };

})();
