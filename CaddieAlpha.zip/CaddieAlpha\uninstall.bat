@echo off
setlocal enabledelayedexpansion
:: ─────────────────────────────────────────────────────────────────
:: Caddie for SOLIDWORKS — COM Unregistration Script
:: Run as Administrator
:: ─────────────────────────────────────────────────────────────────
title Caddie Add-in Unregistration

set "GUID=8C3A5E2D-1B7F-4C6A-9E8D-3F5A2B7C4E1D"

echo.
echo Caddie for SOLIDWORKS -- Unregistration
echo -----------------------------------------

:: ── Admin check ──────────────────────────────────────────────────
net session >nul 2>&1
if !ERRORLEVEL! NEQ 0 (
    echo ERROR: Must run as Administrator. Right-click ^> "Run as administrator".
    pause & exit /b 1
)
echo [OK] Running as Administrator
echo.

:: ── Remove all registry keys ─────────────────────────────────────
echo Removing COM registry keys...
reg delete "HKLM\SOFTWARE\Classes\CLSID\{%GUID%}"                   /f >nul 2>&1
reg delete "HKLM\SOFTWARE\Classes\CaddieForSolidWorks.CaddieAddin"  /f >nul 2>&1

echo Removing SolidWorks add-in key...
reg delete "HKLM\SOFTWARE\SolidWorks\Addins\{%GUID%}"               /f >nul 2>&1

echo.
echo Done. Restart SolidWorks to finish removal.
echo.
pause
