# Caddie for SOLIDWORKS — Install Guide (Alpha)

Thanks for trying Caddie! This guide gets you from zero to chatting with your SolidWorks models in about 5 minutes.

---

## What You'll Need

- **SolidWorks 2022 or newer** (64-bit, any edition)
- **Windows 10 or 11** (64-bit)
- **Microsoft Edge / WebView2 Runtime** — already installed on most Windows machines. If the panel shows a WebView2 error, download from:
  https://developer.microsoft.com/microsoft-edge/webview2/
- **An OpenAI API key** — we'll give you one to use, or you can use your own.

---

## Step 1 — Receive the Add-in Package

You should have received a zip file or folder called `CaddieAlpha`. Inside:

```
CaddieAlpha/
├── Caddie.SwAddin.dll      ← the add-in
├── Caddie.Context.dll
├── Caddie.Ai.dll
├── Caddie.Memory.dll
├── *.dll                   ← supporting libraries
├── ui/                     ← the taskpane interface
├── install.bat             ← run this first!
└── uninstall.bat
```

**Copy this entire folder somewhere stable** (e.g., `C:\Caddie\`). Don't put it in Downloads — the DLL needs to stay in a fixed location.

---

## Step 2 — Run the Installer

1. Right-click `install.bat` → **Run as Administrator**
2. You'll see a console window run `regasm`. It should finish with `"Types registered successfully"`.
3. Press any key to close.

If you get a UAC prompt, click **Yes**.

---

## Step 3 — Enable in SolidWorks

1. Open **SolidWorks**.
2. Go to **Tools → Add-Ins…**
3. Find **"Caddie"** in the list.
4. Check the box in the **Active** column AND the **Start Up** column.
5. Click **OK**.

A panel labelled "**Ask Caddie**" will appear on the right side of SolidWorks. If you don't see it, look under **View → Toolbars → Task Panes**.

---

## Step 4 — Try It!

1. Open any `.SLDPRT`, `.SLDASM`, or `.SLDDRW` file.
2. Caddie **automatically captures your model context** — you'll see the feature info appear in the panel header within a few seconds.
3. Type a question like:
   - *"What features are in this part?"*
   - *"How should I approach shelling this model?"*
   - *"Review my feature tree for best practices."*
4. Press **Enter** and watch Caddie respond.

> **Tip:** Hit the **↻ Refresh** button any time you want to force an immediate context update (e.g. after adding new features).

---

## What to Try

| Ask Caddie... | What it does |
|---------------|--------------|
| "What features are in this part?" | Lists your feature tree |
| "Why might this rebuild fail?" | Analyses errors in context |
| "Walk me through a CSWP bracket exercise" | Starts a guided tutorial |
| "Review my model" | Gives a prioritized improvement list |

---

## Data & Privacy

- Everything is stored on **your machine only** in `%AppData%\CaddieAddin\`.
- To generate responses, your model data (feature names, dimensions, document title) is sent to OpenAI's API. No raw geometry or file data leaves your machine.
- No data is sent to CADvice servers.
- To uninstall: run `uninstall.bat` as Administrator, then delete the Caddie folder.

---

## Something Broke?

1. Check the **Debug** tab → **Log** in the Caddie panel.
2. Or open `%AppData%\CaddieAddin\caddie.log` in Notepad.
3. Send us the log and we'll fix it fast. Email: **hello@cadvice.app**

---

## Uninstall

1. Close SolidWorks.
2. Right-click `uninstall.bat` → **Run as Administrator**.
3. Delete the Caddie folder.
4. Done — no registry junk left behind.
