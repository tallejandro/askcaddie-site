@echo off
setlocal enabledelayedexpansion

echo ============================================================
echo  Caddie for SOLIDWORKS — Update Tool
echo ============================================================
echo.

:: ── Read install path from registry ─────────────────────────────
set "GUID={8C3A5E2D-1B7F-4C6A-9E8D-3F5A2B7C4E1D}"
set "REG_KEY=HKLM\SOFTWARE\Classes\CLSID\%GUID%\InprocServer32"

for /f "tokens=2*" %%A in ('reg query "%REG_KEY%" /v CodeBase 2^>nul') do (
    set "CODEPATH=%%B"
)

if not defined CODEPATH (
    echo ERROR: Caddie does not appear to be registered.
    echo        Run install.bat first, then retry.
    pause
    exit /b 1
)

:: Convert file:///C:/path/Caddie.SwAddin.dll → C:\path\
set "CODEPATH=!CODEPATH:file:///=!"
set "CODEPATH=!CODEPATH:/=\!"
for %%F in ("!CODEPATH!") do set "INSTALL_DIR=%%~dpF"

echo Caddie is installed at: %INSTALL_DIR%
echo.

:: ── Check SolidWorks is not running ──────────────────────────────
:check_sw
tasklist /fi "imagename eq SLDWORKS.EXE" 2>nul | find /i "SLDWORKS.EXE" >nul
if %errorlevel%==0 (
    echo SolidWorks is currently running.
    echo Please save your work and close SolidWorks before updating.
    echo.
    set /p WAIT=Press Enter to check again, or Ctrl+C to cancel:
    goto check_sw
)

:: ── Locate the new DLLs (script must be in same folder as new files) ──
set "NEW_DIR=%~dp0"

echo Copying updated files to %INSTALL_DIR%...
echo.

xcopy /Y /E /I "%NEW_DIR%*.dll" "%INSTALL_DIR%"
if %errorlevel% neq 0 (
    echo ERROR: Failed to copy DLL files.
    echo        Make sure the new DLLs are in the same folder as this script.
    pause
    exit /b 1
)

if exist "%NEW_DIR%ui\" (
    xcopy /Y /E /I "%NEW_DIR%ui\" "%INSTALL_DIR%ui\"
    if %errorlevel% neq 0 (
        echo WARNING: Failed to copy some UI files.
    )
)

echo.
echo ============================================================
echo  Update complete! No re-registration needed.
echo ============================================================
echo.
echo You can now reopen SolidWorks.
echo.
pause
