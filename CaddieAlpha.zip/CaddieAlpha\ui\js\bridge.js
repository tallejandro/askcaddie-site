/**
 * bridge.js — Caddie JS ↔ C# WebView2 bridge
 *
 * Outbound (JS → C#):  window.chrome.webview.postMessage(JSON string)
 * Inbound  (C# → JS):  window.caddieReceive(object)
 *
 * All calls are fire-and-forget except where requestId is used to
 * correlate async responses.
 */

;(function() {
  'use strict';

  // ─── Internal state ──────────────────────────────────────────
  const _handlers = {};   // type → [callback, ...]
  let _reqCounter = 0;
  const _pending = {};    // requestId → { resolve, reject, timeout }

  // ─── Inbound dispatcher ──────────────────────────────────────

  /** Called by C# via ExecuteScriptAsync */
  window.caddieReceive = function(msg) {
    const type = msg && msg.type;
    if (!type) return;

    // Resolve a pending request if requestId matches
    const reqId = msg.requestId;
    if (reqId && _pending[reqId]) {
      const pending = _pending[reqId];
      clearTimeout(pending.timeout);

      const isError = type.includes('ERROR');
      if (isError) {
        pending.reject(new Error(msg.error || type));
      } else {
        pending.resolve(msg);
      }
      delete _pending[reqId];
    }

    // Broadcast to all registered handlers for this type
    const list = _handlers[type] || [];
    list.forEach(fn => {
      try { fn(msg); } catch(e) { console.error('Bridge handler error:', e); }
    });

    // Also broadcast to '*' wildcard handlers
    (_handlers['*'] || []).forEach(fn => {
      try { fn(msg); } catch(e) { console.error('Bridge * handler error:', e); }
    });
  };

  // ─── Outbound ────────────────────────────────────────────────

  function send(payload) {
    try {
      if (window.chrome && window.chrome.webview) {
        // Post the object directly — WebView2 serialises it to JSON automatically.
        // C# reads it via e.WebMessageAsJson which gives {"type":"...",...} ready to parse.
        window.chrome.webview.postMessage(payload);
      } else {
        // Dev mode: log to console
        console.log('[Bridge →]', payload);
      }
    } catch(e) {
      console.error('Bridge send error:', e);
    }
  }

  /**
   * Send a message and return a Promise that resolves when C# responds
   * with the same requestId.
   */
  function request(type, extraData, timeoutMs = 30000) {
    const requestId = 'req-' + (++_reqCounter);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        delete _pending[requestId];
        reject(new Error(`Bridge timeout: ${type}`));
      }, timeoutMs);

      _pending[requestId] = { resolve, reject, timeout };
      send({ type, requestId, ...extraData });
    });
  }

  // ─── Event subscription ───────────────────────────────────────

  function on(type, handler) {
    if (!_handlers[type]) _handlers[type] = [];
    _handlers[type].push(handler);
    return () => off(type, handler); // returns unsubscribe fn
  }

  function off(type, handler) {
    if (_handlers[type])
      _handlers[type] = _handlers[type].filter(h => h !== handler);
  }

  // ─── Public API ───────────────────────────────────────────────

  window.bridge = {
    on,
    off,
    send,
    request,

    // Convenience wrappers
    captureFast:    ()       => request('CAPTURE_FAST', {}, 15000),
    captureDeep:    ()       => request('CAPTURE_DEEP', {}, 60000),
    cancelCapture:  ()       => send({ type: 'CANCEL_CAPTURE' }),
    sendChat:       (content)=> { const id='req-'+(++_reqCounter); send({ type:'CHAT_MESSAGE', content, requestId: id }); return id; },
    cancelChat:     ()       => send({ type: 'CANCEL_CHAT' }),
    clearChat:      ()       => send({ type: 'CLEAR_CHAT' }),
    getSettings:    ()       => request('GET_SETTINGS'),
    saveSettings:   (data)   => request('SAVE_SETTINGS', { data }),
    getHistory:     ()       => request('GET_HISTORY'),
    getSessionMessages:(sid) => request('GET_SESSION_MESSAGES', { sessionId: sid }),
    deleteSession:  (sid)    => send({ type: 'DELETE_SESSION', sessionId: sid }),
    getProjectNote: ()       => request('GET_PROJECT_NOTE'),
    saveProjectNote:(note)   => send({ type: 'SAVE_PROJECT_NOTE', note }),
    getLog:         ()       => request('GET_LOG'),
    openFile:       (path)   => send({ type: 'OPEN_FILE', path }),
    ready:          ()       => send({ type: 'READY' }),
  };

})();
