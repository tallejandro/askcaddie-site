@echo off
setlocal enabledelayedexpansion
:: ─────────────────────────────────────────────────────────────────
:: Caddie for SOLIDWORKS — COM Registration Script
:: Run as Administrator
::
:: Does NOT use RegAsm — writes registry keys directly to avoid
:: the SolidWorks interop DLL dependency-load issue.
:: ─────────────────────────────────────────────────────────────────
title Caddie Add-in Registration

set "GUID=8C3A5E2D-1B7F-4C6A-9E8D-3F5A2B7C4E1D"
set "LOG=%~dp0register.log"

echo Caddie Registration -- %DATE% %TIME% > "%LOG%"

echo.
echo Caddie for SOLIDWORKS -- Registration
echo ----------------------------------------

:: ── Admin check ──────────────────────────────────────────────────
net session >nul 2>&1
if !ERRORLEVEL! NEQ 0 (
    echo ERROR: Must run as Administrator. Right-click ^> "Run as administrator".
    echo ERROR: Not running as Administrator >> "%LOG%"
    pause & exit /b 1
)
echo [OK] Running as Administrator
echo [OK] Running as Administrator >> "%LOG%"

:: ── Find the DLL ─────────────────────────────────────────────────
set "DLL_NAME=Caddie.SwAddin.dll"
set "DLL_PATH="

set "TRY=%~dp0..\src\Caddie.SwAddin\bin\x64\Debug\net48\%DLL_NAME%"
if exist "!TRY!" (
    for %%F in ("!TRY!") do set "DLL_PATH=%%~fF"
    echo [OK] Found Debug build
    echo [OK] Found Debug build >> "%LOG%"
)

if "!DLL_PATH!"=="" (
    set "TRY=%~dp0..\src\Caddie.SwAddin\bin\x64\Release\net48\%DLL_NAME%"
    if exist "!TRY!" (
        for %%F in ("!TRY!") do set "DLL_PATH=%%~fF"
        echo [OK] Found Release build
        echo [OK] Found Release build >> "%LOG%"
    )
)

if "!DLL_PATH!"=="" (
    set "TRY=%~dp0%DLL_NAME%"
    if exist "!TRY!" (
        for %%F in ("!TRY!") do set "DLL_PATH=%%~fF"
        echo [OK] Found DLL next to script
        echo [OK] Found DLL next to script >> "%LOG%"
    )
)

if "!DLL_PATH!"=="" (
    echo.
    echo ERROR: Cannot find %DLL_NAME%.
    echo.
    echo Searched:
    echo   %~dp0..\src\Caddie.SwAddin\bin\x64\Debug\net48\
    echo   %~dp0..\src\Caddie.SwAddin\bin\x64\Release\net48\
    echo.
    echo Build the solution first: Build ^> Rebuild Solution, Platform = x64.
    echo ERROR: DLL not found >> "%LOG%"
    pause & exit /b 1
)

echo DLL: !DLL_PATH!
echo DLL: !DLL_PATH! >> "%LOG%"
echo.

:: ── Build file:/// URL for CodeBase ──────────────────────────────
set "DLL_URL=!DLL_PATH:\=/!"
set "DLL_URL=file:///!DLL_URL!"

:: ── Write all registry keys directly (no RegAsm) ─────────────────
:: RegAsm fails because it tries to load SW interop DLLs at
:: registration time. Writing keys directly avoids that entirely.
echo Writing registry keys...
echo Writing registry keys... >> "%LOG%"

set "CLSID_KEY=HKLM\SOFTWARE\Classes\CLSID\{%GUID%}"
set "PROGID=CaddieForSolidWorks.CaddieAddin"
set "CLASS=Caddie.SwAddin.CaddieAddin"
set "ASSY=Caddie.SwAddin, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null"
set "SW_KEY=HKLM\SOFTWARE\SolidWorks\Addins\{%GUID%}"

:: COM CLSID root
reg add "%CLSID_KEY%"                /ve /d "%CLASS%"        /f >> "%LOG%" 2>&1

:: InprocServer32 — .NET COM objects always point to mscoree.dll
reg add "%CLSID_KEY%\InprocServer32" /ve /d "mscoree.dll"    /f >> "%LOG%" 2>&1
reg add "%CLSID_KEY%\InprocServer32" /v ThreadingModel /t REG_SZ /d "Both"        /f >> "%LOG%" 2>&1
reg add "%CLSID_KEY%\InprocServer32" /v Class          /t REG_SZ /d "%CLASS%"     /f >> "%LOG%" 2>&1
reg add "%CLSID_KEY%\InprocServer32" /v Assembly        /t REG_SZ /d "%ASSY%"      /f >> "%LOG%" 2>&1
reg add "%CLSID_KEY%\InprocServer32" /v RuntimeVersion  /t REG_SZ /d "v4.0.30319" /f >> "%LOG%" 2>&1
reg add "%CLSID_KEY%\InprocServer32" /v CodeBase        /t REG_SZ /d "!DLL_URL!"  /f >> "%LOG%" 2>&1

:: ProgID link
reg add "%CLSID_KEY%\ProgID"         /ve /d "%PROGID%"       /f >> "%LOG%" 2>&1

:: ProgID root
reg add "HKLM\SOFTWARE\Classes\%PROGID%"        /ve /d "%CLASS%"    /f >> "%LOG%" 2>&1
reg add "HKLM\SOFTWARE\Classes\%PROGID%\CLSID"  /ve /d "{%GUID%}"   /f >> "%LOG%" 2>&1

:: SolidWorks add-in key
reg add "%SW_KEY%" /ve /t REG_DWORD /d 0                                                  /f >> "%LOG%" 2>&1
reg add "%SW_KEY%" /v Title         /t REG_SZ   /d "Caddie"                                /f >> "%LOG%" 2>&1
reg add "%SW_KEY%" /v Description   /t REG_SZ   /d "Caddie for SOLIDWORKS - AI Copilot"    /f >> "%LOG%" 2>&1

set "RC=!ERRORLEVEL!"

echo.
if !RC! EQU 0 (
    echo ────────────────────────────────────────────────────────
    echo  SUCCESS: Caddie registered.
    echo.
    echo  Next steps:
    echo    1. Open SolidWorks  (restart it if already running^)
    echo    2. Go to: Tools ^> Add-Ins
    echo    3. Check the box next to "Caddie"
    echo    4. Click OK  — the Caddie taskpane will appear
    echo ────────────────────────────────────────────────────────
    echo SUCCESS >> "%LOG%"
) else (
    echo FAILED: Last reg add returned error code !RC!
    echo See details in: %~dp0register.log
    echo FAILED RC=!RC! >> "%LOG%"
)

echo.
pause
