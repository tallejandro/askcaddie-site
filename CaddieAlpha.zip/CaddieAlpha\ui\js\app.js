/**
 * app.js — Caddie Taskpane main controller
 *
 * Wires up:
 *  - Tab navigation
 *  - Quick action buttons (Capture, Deep, Clear, Copy)
 *  - Chat input / send
 *  - C# → JS message routing
 *  - Settings load/save
 *  - History panel
 *  - Debug panel
 *  - Teach Me panel
 */

;(function() {
  'use strict';

  // ─── State ──────────────────────────────────────────────────
  const state = {
    activeTab: 'chat',
    currentContext: null,
    currentContextJson: null,
    isCapturing: false,
    settings: {}
  };

  // ─── Tab routing ─────────────────────────────────────────────

  function initTabs() {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
  }

  function switchTab(tabName) {
    state.activeTab = tabName;

    document.querySelectorAll('.tab-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabName);
    });

    document.querySelectorAll('.tab-panel').forEach(p => {
      p.classList.remove('active');
    });

    const panel = document.getElementById('tab-' + tabName);
    if (panel) panel.classList.add('active');

    // Lazy-load tab content
    if (tabName === 'history') loadHistory();
    if (tabName === 'settings') loadSettings();
    if (tabName === 'debug') refreshDebugLog();
  }

  // ─── Status indicator ─────────────────────────────────────────

  function setStatus(label, state_) {
    const dot = document.getElementById('status-dot');
    const lbl = document.getElementById('status-label');
    if (dot) {
      dot.className = 'status-dot';
      if (state_) dot.classList.add(state_);
    }
    if (lbl) lbl.textContent = label;
  }

  // ─── Toast notifications ─────────────────────────────────────

  function showToast(message, type, durationMs) {
    durationMs = durationMs || 2500;
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = 'toast' + (type ? ' ' + type : '');
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(() => toast.remove(), 300);
    }, durationMs);
  }

  // ─── Chat / Input ─────────────────────────────────────────────

  function initChatInput() {
    const input = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');

    if (!input || !sendBtn) return;

    // Auto-resize textarea
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    });

    // Enter to send (Shift+Enter for newline)
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    sendBtn.addEventListener('click', sendMessage);
  }

  function sendMessage() {
    const input = document.getElementById('user-input');
    if (!input) return;

    const content = input.value.trim();
    if (!content) return;
    if (chatUI.isStreaming()) {
      bridge.cancelChat();
      return;
    }

    input.value = '';
    input.style.height = 'auto';

    // Show user message immediately
    chatUI.addMessage('user', content, {
      hasContext: !!state.currentContext,
      contextLabel: state.currentContext
        ? (state.currentContext.document?.title || 'Model context')
        : null,
      contextData: state.currentContext || null
    });

    // Switch send button to cancel
    const sendBtn = document.getElementById('send-btn');
    if (sendBtn) { sendBtn.textContent = '⏹'; sendBtn.title = 'Cancel'; }

    setStatus('thinking…', 'busy');

    // Stream response — startStreaming() is called by the AI_START event handler
    // when C# confirms the stream has begun. Calling it here too creates a duplicate
    // "..." placeholder that never gets cleaned up.
    const reqId = bridge.sendChat(content);
  }

  // ─── Quick actions ─────────────────────────────────────────────

  function initQuickActions() {
    // Refresh = manual fast snapshot (Caddie auto-captures on doc changes,
    // but user can force-refresh anytime)
    el('btn-capture-fast')?.addEventListener('click', captureFast);
    el('btn-capture-cancel')?.addEventListener('click', cancelCapture);
    el('btn-clear-chat')?.addEventListener('click', () => {
      chatUI.clearMessages();
      bridge.clearChat();
    });
    el('btn-copy-last')?.addEventListener('click', () => {
      const text = chatUI.getLastResponseText();
      if (text) {
        navigator.clipboard.writeText(text)
          .then(() => showToast('Copied to clipboard', 'success'))
          .catch(() => showToast('Copy failed', 'error'));
      } else {
        showToast('Nothing to copy yet', '');
      }
    });
  }

  function captureFast() {
    if (state.isCapturing) return;
    state.isCapturing = true;
    setCaptureBtnState(true);
    setStatus('capturing…', 'busy');

    // Fire and forget — CONTEXT_READY broadcast handler calls onContextReady()
    bridge.captureFast()
      .catch(err => {
        setStatus('capture error', 'error');
        showToast(err.message || 'Capture failed', 'error');
      })
      .finally(() => {
        state.isCapturing = false;
        setCaptureBtnState(false);
      });
  }

  function cancelCapture() {
    bridge.cancelCapture();
    state.isCapturing = false;
    setCaptureBtnState(false);
    setStatus('cancelled', '');
  }

  function setCaptureBtnState(active) {
    el('btn-capture-fast')?.style.setProperty('display', active ? 'none' : '');
    el('btn-capture-cancel')?.style.setProperty('display', active ? '' : 'none');
  }

  // ─── Context ready handler ─────────────────────────────────────

  function onContextReady(msg) {
    const data = msg.data;
    if (!data) return;

    state.currentContext = data.packet;
    state.currentContextJson = data.json;

    // Update status
    const doc = data.packet && data.packet.document;
    const title = doc ? doc.title || 'Untitled' : 'No doc';
    const duration = data.durationMs ? ` (${data.durationMs}ms)` : '';
    setStatus(`${title}${duration}`, 'online');

    // Update context indicator
    const ctxStatus = el('context-status');
    const ctxText = el('context-status-text');
    if (ctxStatus) ctxStatus.classList.add('has-context');
    if (ctxText) {
      ctxText.textContent = title;
    }

    // Update debug tab
    if (state.currentContextJson) {
      try {
        const parsed = JSON.parse(state.currentContextJson);
        inspector.renderJson(parsed, el('json-tree'));
      } catch (e) {
        if (el('json-tree')) el('json-tree').textContent = state.currentContextJson;
      }
    }

    // Update screenshot
    if (data.screenshotThumb) {
      inspector.showScreenshot(
        data.screenshotThumb,
        data.screenshotPath,
        data.packet?.visual?.width,
        data.packet?.visual?.height
      );
    }

  }

  // ─── Bridge event handlers ─────────────────────────────────────

  function initBridgeHandlers() {
    // CONTEXT_READY fires for both manual refreshes and auto-captures from C#.
    // This single handler covers all cases — the Promise in captureFast() also
    // resolves, but onContextReady() is idempotent so calling it twice is harmless.
    bridge.on('CONTEXT_READY', (msg) => {
      state.isCapturing = false;
      setCaptureBtnState(false);
      onContextReady(msg);
    });

    // AI streaming
    bridge.on('AI_START', () => {
      chatUI.startStreaming();
    });

    bridge.on('AI_CHUNK', (msg) => {
      chatUI.appendChunk(msg.content || '');
    });

    bridge.on('AI_DONE', () => {
      chatUI.finishStreaming();
      setStatus('ready', 'online');
      const sendBtn = el('send-btn');
      if (sendBtn) { sendBtn.textContent = '➤'; sendBtn.title = 'Send (Enter)'; }
    });

    bridge.on('AI_CANCELLED', () => {
      chatUI.cancelStreaming();
      setStatus('ready', 'online');
      const sendBtn = el('send-btn');
      if (sendBtn) { sendBtn.textContent = '➤'; sendBtn.title = 'Send (Enter)'; }
    });

    bridge.on('AI_ERROR', (msg) => {
      chatUI.addError(msg.error || 'Unknown AI error');
      setStatus('error', 'error');
      const sendBtn = el('send-btn');
      if (sendBtn) { sendBtn.textContent = '➤'; sendBtn.title = 'Send (Enter)'; }
      showToast(msg.error || 'AI error', 'error', 4000);
    });

    // Capture progress (deep mode)
    bridge.on('CAPTURE_PROGRESS', (msg) => {
      setStatus(msg.message || 'capturing…', 'busy');
    });

    // SW events
    bridge.on('SW_EVENT', (msg) => {
      switch (msg.eventType) {
        case 'DOC_CHANGED':
        case 'FILE_NEW':
        case 'FILE_OPEN':
          // C# will auto-capture and send CONTEXT_READY shortly.
          // Just show a brief "updating" status while we wait.
          setStatus('updating…', 'busy');
          const ctxText = el('context-status-text');
          if (ctxText) ctxText.textContent = 'Updating context…';
          break;
        case 'FILE_SAVED':
          showToast('Model saved', 'success', 1500);
          break;
        case 'FILE_CLOSE':
          setStatus('no document', '');
          state.currentContext = null;
          state.currentContextJson = null;
          const ctxStatus = el('context-status');
          if (ctxStatus) ctxStatus.classList.remove('has-context');
          const ctxLabel = el('context-status-text');
          if (ctxLabel) ctxLabel.textContent = 'No document open';
          break;
      }
    });

    // Settings data returned
    bridge.on('SETTINGS_DATA', (msg) => {
      if (msg.data) applySettingsToForm(msg.data);
    });

    // Capture started
    bridge.on('CAPTURE_STARTED', (msg) => {
      setStatus(msg.mode === 'deep' ? 'deep capture…' : 'capturing…', 'busy');
    });

    // Update available
    bridge.on('UPDATE_AVAILABLE', ({ version, downloadUrl, releaseNotes }) => {
      const verEl = el('update-version');
      const linkEl = el('update-link');
      const notesEl = el('update-notes');
      const barEl = el('update-bar');
      if (verEl) verEl.textContent = version;
      if (linkEl) linkEl.href = downloadUrl || '#download';
      if (notesEl && releaseNotes) notesEl.textContent = ' — ' + releaseNotes;
      if (barEl) barEl.classList.remove('hidden');
    });
  }

  function dismissUpdateBar() {
    const bar = el('update-bar');
    if (bar) bar.classList.add('hidden');
  }

  // Expose for inline onclick attribute on the close button
  window.dismissUpdateBar = dismissUpdateBar;

  // ─── Settings ─────────────────────────────────────────────────

  function loadSettings() {
    bridge.getSettings()
      .then(msg => { if (msg.data) applySettingsToForm(msg.data); })
      .catch(() => {});
  }

  function applySettingsToForm(cfg) {
    state.settings = cfg;
    if (el('setting-name'))        el('setting-name').value         = cfg.userName || cfg.UserName || '';
    if (el('setting-memory'))      el('setting-memory').checked     = cfg.memoryEnabled !== false && cfg.MemoryEnabled !== false;
    if (el('setting-autocapture')) el('setting-autocapture').checked = cfg.autoCapture !== false && cfg.AutoCapture !== false;
  }

  function initSettings() {
    el('btn-save-settings')?.addEventListener('click', () => {
      const data = {
        userName:      el('setting-name')?.value          || '',
        memoryEnabled: el('setting-memory')?.checked      ?? true,
        autoCapture:   el('setting-autocapture')?.checked ?? true,
      };
      bridge.saveSettings(data)
        .then(() => {
          const statusEl = el('settings-save-status');
          if (statusEl) {
            statusEl.textContent = '✓ Saved';
            setTimeout(() => { statusEl.textContent = ''; }, 2000);
          }
          showToast('Settings saved', 'success');
        })
        .catch(err => showToast('Save failed: ' + err.message, 'error'));
    });
  }

  // ─── History panel ─────────────────────────────────────────────

  function loadHistory() {
    bridge.getHistory()
      .then(msg => renderHistory(msg.sessions || []))
      .catch(() => {});
  }

  function renderHistory(sessions) {
    const panel = el('history-panel');
    if (!panel) return;

    if (!sessions || sessions.length === 0) {
      panel.innerHTML = `<div class="empty-state"><div class="empty-icon">📜</div>
        <p>No conversation history yet.</p></div>`;
      return;
    }

    panel.innerHTML = '';
    sessions.forEach(s => {
      const item = document.createElement('div');
      item.className = 'session-item';

      const date = new Date(s.updatedAt || s.UpdatedAt || s.createdAt || s.CreatedAt);
      const dateStr = date.toLocaleDateString(undefined, { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' });
      const fileTitle = s.fileTitle || s.FileTitle || '';
      const title = s.title || s.Title || 'Session';
      const summary = s.summary || s.Summary || '';

      item.innerHTML = `
        <div class="session-title">${escapeHtml(title)}</div>
        <div class="session-meta">
          <span>${escapeHtml(fileTitle || 'No file')}</span>
          <span>${dateStr}</span>
        </div>
        ${summary ? `<div class="session-summary">${escapeHtml(summary)}</div>` : ''}
      `;

      item.addEventListener('click', () => loadSessionMessages(s.id || s.Id, title));
      panel.appendChild(item);
    });
  }

  function loadSessionMessages(sessionId, title) {
    bridge.getSessionMessages(sessionId)
      .then(msg => {
        switchTab('chat');
        chatUI.clearMessages();
        chatUI.addMessage('system', `**Viewing session:** ${title}`);
        (msg.messages || []).forEach(m => {
          chatUI.addMessage(m.role || m.Role, m.content || m.Content);
        });
      })
      .catch(err => showToast('Could not load session: ' + err.message, 'error'));
  }

  // ─── History search ────────────────────────────────────────────

  function initHistorySearch() {
    let _allSessions = [];
    bridge.on('HISTORY_DATA', (msg) => { _allSessions = msg.sessions || []; });

    el('history-search')?.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      if (!q) { renderHistory(_allSessions); return; }
      const filtered = _allSessions.filter(s =>
        (s.title || '').toLowerCase().includes(q) ||
        (s.summary || '').toLowerCase().includes(q) ||
        (s.fileTitle || '').toLowerCase().includes(q)
      );
      renderHistory(filtered);
    });
  }

  // ─── Debug tab ─────────────────────────────────────────────────

  function initDebugPanel() {
    document.querySelectorAll('.debug-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.debug-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.dataset.debugTab;
        el('debug-context')?.classList.toggle('hidden', tab !== 'context');
        el('debug-screenshot')?.classList.toggle('hidden', tab !== 'screenshot');
        el('debug-log')?.classList.toggle('hidden', tab !== 'log');
        if (tab === 'log') refreshDebugLog();
      });
    });

    el('btn-debug-capture')?.addEventListener('click', captureFast);

    el('btn-debug-copy-json')?.addEventListener('click', () => {
      if (state.currentContextJson) {
        navigator.clipboard.writeText(state.currentContextJson)
          .then(() => showToast('JSON copied', 'success'))
          .catch(() => showToast('Copy failed', 'error'));
      } else {
        showToast('No context to copy', '');
      }
    });

    el('btn-refresh-log')?.addEventListener('click', refreshDebugLog);
    el('btn-copy-log')?.addEventListener('click', () => {
      const log = el('log-view')?.textContent || '';
      navigator.clipboard.writeText(log)
        .then(() => showToast('Log copied', 'success'))
        .catch(() => showToast('Copy failed', 'error'));
    });
  }

  function refreshDebugLog() {
    bridge.getLog()
      .then(msg => {
        if (el('log-view')) el('log-view').textContent = msg.log || '(empty)';
      })
      .catch(() => {});
  }

  // ─── Teach Me panel ───────────────────────────────────────────

  function initTeachPanel() {
    document.querySelectorAll('.teach-card').forEach(card => {
      card.addEventListener('click', () => {
        const exercise = card.dataset.exercise;
        switchTab('chat');
        const prompt = teachExercisePrompt(exercise);
        if (prompt) {
          // Pre-fill the chat input and send
          const input = el('user-input');
          if (input) {
            input.value = prompt;
            input.dispatchEvent(new Event('input'));
            sendMessage();
          }
        }
      });
    });

    // Image drop zone
    const dropZone = el('image-drop-zone');
    const fileInput = el('image-file-input');

    dropZone?.addEventListener('click', () => fileInput?.click());
    dropZone?.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = 'var(--color-primary)';
    });
    dropZone?.addEventListener('dragleave', () => {
      dropZone.style.borderColor = '';
    });
    dropZone?.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.style.borderColor = '';
      const file = e.dataTransfer?.files?.[0];
      if (file) handleImageFile(file);
    });
    fileInput?.addEventListener('change', () => {
      if (fileInput.files?.[0]) handleImageFile(fileInput.files[0]);
    });
  }

  function handleImageFile(file) {
    if (!file.type.startsWith('image/')) {
      showToast('Please select an image file', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      switchTab('chat');
      chatUI.addMessage('system', `📎 Image attached: **${file.name}**\n\n_Caddie will analyse this image when you send your question._`);
      // Store base64 for next chat message
      // For M1, we note the image but vision is M5+
      const input = el('user-input');
      if (input && !input.value) {
        input.value = 'Please look at this model image and give me step-by-step instructions to build it in SolidWorks.';
        input.dispatchEvent(new Event('input'));
      }
      showToast('Image ready — send your message', 'success');
    };
    reader.readAsDataURL(file);
  }

  function teachExercisePrompt(exercise) {
    const prompts = {
      bracket: 'Walk me through building a flanged bracket in SolidWorks from scratch. Include the sketch, extrude, shell, and hole wizard steps.',
      shaft:   'Show me how to create a stepped shaft using a revolve feature, then add a keyway cut and add thread annotations.',
      assembly1: 'Guide me through creating a simple hinge assembly with two plates, using coincident and concentric mates.',
      cswe1:   'Help me understand how to set up a SolidWorks design table with global variables and driven dimensions for a CSWE-style exercise.',
    };
    return prompts[exercise] || null;
  }

  // ─── Review panel ─────────────────────────────────────────────

  function initReviewPanel() {
    el('btn-run-review')?.addEventListener('click', runReview);
  }

  function runReview() {
    if (!state.currentContext) {
      showToast('Capture context first', '');
      captureFast();
      return;
    }

    const statusEl = el('review-status');
    if (statusEl) statusEl.textContent = 'Analysing…';

    setStatus('reviewing…', 'busy');

    // Ask AI to do a structured review
    switchTab('chat');
    const input = el('user-input');
    if (input) {
      input.value = 'Please review my current model and give me a prioritized list of issues and improvements. Format as:\n**Most critical first.** For each: issue name, why it matters, how to fix it.';
      sendMessage();
    }

    if (statusEl) statusEl.textContent = '';
  }

  // ─── Utilities ────────────────────────────────────────────────

  function el(id) { return document.getElementById(id); }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ─── Init ─────────────────────────────────────────────────────

  function init() {
    initTabs();
    initChatInput();
    initQuickActions();
    initBridgeHandlers();
    initSettings();
    initHistorySearch();
    initDebugPanel();
    initTeachPanel();
    initReviewPanel();

    setStatus('connecting…', '');

    // Signal ready to C# backend
    bridge.ready();

    // Set initial status after a tick
    setTimeout(() => {
      if (document.getElementById('status-label')?.textContent === 'connecting…') {
        setStatus('ready', 'online');
      }
    }, 3000);
  }

  // Start when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
