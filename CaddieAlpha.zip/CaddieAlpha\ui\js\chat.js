/**
 * chat.js — Chat message rendering, streaming, and quick actions
 */

;(function() {
  'use strict';

  let _lastAssistantEl = null;
  let _lastResponseText = '';
  let _isStreaming = false;

  // ─── Render a complete message ───────────────────────────────

  function addMessage(role, content, extra) {
    const container = document.getElementById('chat-messages');
    if (!container) return null;

    // Hide welcome state
    const welcome = document.getElementById('welcome-state');
    if (welcome) welcome.style.display = 'none';

    const msgEl = document.createElement('div');
    msgEl.className = `message ${role}`;

    const roleLabel = document.createElement('div');
    roleLabel.className = 'message-role';
    roleLabel.textContent = role === 'user' ? 'You' : role === 'assistant' ? 'Caddie' : 'System';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = renderMarkdown(content);

    msgEl.appendChild(roleLabel);
    msgEl.appendChild(bubble);

    // For user messages with context: make the bubble itself clickable
    // to reveal a compact model-state snapshot. A subtle ▾ arrow indicates it.
    if (role === 'user' && extra && extra.hasContext) {
      bubble.classList.add('has-context');
      bubble.title = 'Click to see model state';

      const arrow = document.createElement('span');
      arrow.className = 'context-arrow';
      arrow.textContent = '▾';
      bubble.appendChild(arrow);

      bubble.addEventListener('click', () => {
        let panel = msgEl.querySelector('.context-details');
        if (panel) {
          panel.remove();
          arrow.textContent = '▾';
          return;
        }

        arrow.textContent = '▴';
        panel = document.createElement('div');
        panel.className = 'context-details';

        const ctx = extra.contextData;
        if (ctx && ctx.document) {
          const doc = ctx.document;
          const featureCount = ctx.features ? ctx.features.length : 0;
          const selCount = (ctx.selection && ctx.selection.count) || 0;
          const rows = [
            ['Type',     doc.type || '—'],
            ['Part',     doc.title || '—'],
            ['Config',   doc.active_config || doc.activeConfig || '—'],
            ['Units',    doc.units || '—'],
            ['Features', featureCount],
          ];
          if (selCount > 0) rows.push(['Selected', selCount]);
          panel.innerHTML = rows.map(([k, v]) =>
            `<div class="ctx-detail-row"><span class="ctx-detail-label">${k}</span><span>${escapeHtml(String(v))}</span></div>`
          ).join('');
        } else {
          panel.textContent = extra.contextLabel || 'Context captured';
        }

        msgEl.appendChild(panel);
      });
    }

    container.appendChild(msgEl);
    scrollToBottom();
    return msgEl;
  }

  // ─── Streaming helpers ───────────────────────────────────────

  function startStreaming() {
    _isStreaming = true;
    _lastResponseText = '';
    const container = document.getElementById('chat-messages');
    if (!container) return;

    const welcome = document.getElementById('welcome-state');
    if (welcome) welcome.style.display = 'none';

    const msgEl = document.createElement('div');
    msgEl.className = 'message assistant';
    msgEl.id = 'streaming-msg';

    const roleLabel = document.createElement('div');
    roleLabel.className = 'message-role';
    roleLabel.textContent = 'Caddie';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble streaming-cursor';
    bubble.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';

    msgEl.appendChild(roleLabel);
    msgEl.appendChild(bubble);
    container.appendChild(msgEl);

    _lastAssistantEl = bubble;
    scrollToBottom();
  }

  function appendChunk(chunk) {
    if (!_lastAssistantEl) return;
    _lastResponseText += chunk;

    // Render markdown progressively
    _lastAssistantEl.className = 'message-bubble streaming-cursor';
    _lastAssistantEl.innerHTML = renderMarkdown(_lastResponseText);
    scrollToBottom();
  }

  function finishStreaming() {
    _isStreaming = false;
    if (_lastAssistantEl) {
      _lastAssistantEl.classList.remove('streaming-cursor');
      // Final render
      _lastAssistantEl.innerHTML = renderMarkdown(_lastResponseText);
    }
    _lastAssistantEl = null;
    scrollToBottom();
  }

  function cancelStreaming(message) {
    _isStreaming = false;
    if (_lastAssistantEl) {
      _lastAssistantEl.classList.remove('streaming-cursor');
      _lastAssistantEl.innerHTML = renderMarkdown(_lastResponseText || '_(cancelled)_');
    }
    _lastAssistantEl = null;
  }

  function addError(message) {
    _isStreaming = false;
    if (_lastAssistantEl) {
      _lastAssistantEl.classList.remove('streaming-cursor');
      _lastAssistantEl.innerHTML = `<span style="color:var(--color-error)">Error: ${escapeHtml(message)}</span>`;
      _lastAssistantEl = null;
    } else {
      addMessage('system', `Error: ${message}`);
    }
    scrollToBottom();
  }

  function clearMessages() {
    const container = document.getElementById('chat-messages');
    if (!container) return;
    container.innerHTML = '';
    const welcome = document.createElement('div');
    welcome.id = 'welcome-state';
    welcome.className = 'empty-state';
    welcome.innerHTML = `
      <img src="assets/Caddie.png" width="80" height="80" style="object-fit:contain">
      <p style="font-size:13px;font-weight:600;color:var(--color-text)">Chat cleared.</p>
      <p>Capture context and ask a new question.</p>`;
    container.appendChild(welcome);
    _lastResponseText = '';
    _lastAssistantEl = null;
    _isStreaming = false;
  }

  function getLastResponseText() { return _lastResponseText; }
  function isStreaming() { return _isStreaming; }

  // ─── Markdown renderer (lightweight, no dependencies) ────────

  function renderMarkdown(text) {
    if (!text) return '';
    let html = escapeHtml(text);

    // Code blocks (must come before inline code)
    html = html.replace(/```[\w]*\n?([\s\S]*?)```/g, '<pre><code>$1</code></pre>');

    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm,  '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm,   '<h1>$1</h1>');

    // Bold + italic
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g,     '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g,         '<em>$1</em>');

    // Horizontal rule
    html = html.replace(/^---$/gm, '<hr>');

    // Bullet lists (collect consecutive lines)
    html = html.replace(/((?:^[•\-\*] .+\n?)+)/gm, (match) => {
      const items = match.split('\n').filter(l => l.trim()).map(l =>
        '<li>' + l.replace(/^[•\-\*] /, '') + '</li>');
      return '<ul>' + items.join('') + '</ul>';
    });

    // Numbered lists
    html = html.replace(/((?:^\d+\. .+\n?)+)/gm, (match) => {
      const items = match.split('\n').filter(l => l.trim()).map(l =>
        '<li>' + l.replace(/^\d+\. /, '') + '</li>');
      return '<ol>' + items.join('') + '</ol>';
    });

    // Paragraphs (double newline → <p>)
    html = html.split(/\n\n+/).map(para => {
      para = para.trim();
      if (!para) return '';
      if (/^<(h[123]|ul|ol|hr|pre|blockquote)/.test(para)) return para;
      return '<p>' + para.replace(/\n/g, '<br>') + '</p>';
    }).join('\n');

    return html;
  }

  // ─── Utils ───────────────────────────────────────────────────

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function scrollToBottom() {
    const container = document.getElementById('chat-messages');
    if (container) {
      requestAnimationFrame(() => {
        container.scrollTop = container.scrollHeight;
      });
    }
  }

  // ─── Export ──────────────────────────────────────────────────

  window.chatUI = {
    addMessage,
    startStreaming,
    appendChunk,
    finishStreaming,
    cancelStreaming,
    addError,
    clearMessages,
    getLastResponseText,
    isStreaming,
    renderMarkdown,
    scrollToBottom,
  };

})();
